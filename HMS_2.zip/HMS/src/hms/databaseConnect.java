/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hms;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author united computer
 */
public class databaseConnect {
    Connection conn = null;
    public static Connection ConnectionDB(){
        try{
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\united computer\\Documents\\NetBeansProjects\\HMS\\HMS_Database.sqlite");
            return conn;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Database Not connected");
            return null;
        }
    
}
}
